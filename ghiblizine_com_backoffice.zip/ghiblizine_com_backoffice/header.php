<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ghiblizine
 */

?>

<header class="gridMain">
    <p>Ghiblizine</p>
    <img alt="Studio Ghibli logo" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Logo.png" width="20%" height="auto" class="mH">
    <p class="mH">a</p>
    <p class="mH">magazine</p>

    <button onclick="myFunction()" class="menu">
      <div class="menu">
        <span class="mHi"></span>
        <span class="mHi"></span>
        <span class="mHi"></span>
      </div>
    </button>



       <nav class="mH">
       <ul>
       <li><a href="Homepage">HOMEPAGE</a></li>
       <li><a href="movies">MOVIES</a></li>
        <li><a href="characters">CHARACTERS</a></li>
        <li><a href="about">ABOUT US</a></li>
 
    
      </ul>
    </nav>



    <!-- <nav class="mH">
      <ul>
      <?php /*wp_nav_menu(
    array(
    'theme_location' => 'Menu1',       
    'container'=> false,
    'items_wrap' => '%3$s',
)
); */?>
      </ul>
    </nav> -->

    <script>
    function myFunction() {
      document.querySelector("nav.mH").classList.toggle("mostra");
    }


    window.onclick = function (event) {
      if (!event.target.matches('.menu')) {
        var menu = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
          }
        }
      }
    }
  </script>

  </header>