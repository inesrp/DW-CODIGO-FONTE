<?php
/**
 * Template Name: Movies
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ghiblizine
 */?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>
	<script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>
    <script type="text/javascript">
    var url = "<?php echo get_template_directory_uri(); ?>/assets/";
    </script>

<?php wp_head(); ?>
</head>

<body id="movies" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php

get_header();
?>

<div class= "wrapper">
    <main>

    <div id="titleCont">
        <h1>MOVIES</h1>

        <img id="filter" alt="filter icon" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/filter.png" width="2%" height="auto">

        <div id="searchContainer">
            <form action="">
            <button type="submit"><img alt="search icon" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/search.png" width="55%" height="auto"></button>
            <input type="text" placeholder="Search Movie..." name="search">
            </form>
        </div>
    </div>

    <img id="dustPos1" alt="dust totorto" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="10%" height="auto">
    <img id="dustPos2" alt="dust totorto" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="20%" height="auto">
    <img id="dustPos3" alt="dust totorto" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="10%" height="auto">

<?php

 // The Query
 $the_query = new WP_Query( array(
'post_type' => 'ghibli-movies',
'orderby' => 'name',
'order'   => 'DESC',
'posts_per_page' => 9,
 ) );
  
 // The Loop
 if ( $the_query->have_posts() ):
 ?>
    <div id="moviesContainer">
    <?php
     while ( $the_query->have_posts() ) :
     $the_query->the_post();
    ?>
    
    <a href="<?php the_permalink();?>">
    <div>
        <img src="<?php echo get_field('movie_photo')['url']; ?>">

        <?php $genre = get_field('genre'); ?> 
        <?php $year = get_field('year'); ?>  

        <span><?php the_title();?></span>
        <span><?php echo $year?></span>
        <span><?php echo $genre?></span>
    

    </div>
     </a>
    <?php endwhile;
     wp_reset_postdata();
     wp_reset_query();
    ?>

    </div>

<?php
 endif;
 /* Restore original Post Data */
 wp_reset_postdata();
 ?>

    <div id="nPag"> 
		 <div>
                    <span>1</span>
                </div></div>

    </main>
	
	<footer id="movF">
            <img id="Haku" alt="Haku" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (2).png" width="75%" height="auto">


<?php
get_footer();
