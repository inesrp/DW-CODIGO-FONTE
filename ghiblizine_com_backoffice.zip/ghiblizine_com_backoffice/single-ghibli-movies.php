<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Ghiblizine
 */
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible'>
    <title>Ghiblizine</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>

    <script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>

</head>

<body id="article">

<?php
get_header();
?>

<div class="wrapper">
        <main>
            <?php 
            $artigoID=get_field('ghibli-characters')->ID;
            
            ?>
            <div>
                <h1><?php the_title() ?></h1>
                <h1 style="font-size:30px;margin-bottom:0;"> Synopsys of the Movie  </h1>
                <p>
				<?php echo get_field("sinopsis"); ?>
                </p>
                <img style="width:60%" src="<?php echo get_field('movie_photo',$artigoID)['url']; ?>">
                <div>
                <span><?php echo get_field("year"); ?>, </span>
                <span><?php echo get_field("genre"); ?></span>
</div>
            </div>

        </main>

		
        <footer>
<?php
get_footer();
?>

