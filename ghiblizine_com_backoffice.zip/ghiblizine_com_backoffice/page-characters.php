<?php
/**
 * Template Name: Characters
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ghiblizine
 */?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>
	<script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>
    <script type="text/javascript">
    var url = "<?php echo get_template_directory_uri(); ?>/assets/";
    </script>
<?php wp_head(); ?>
</head>

<body id="Char" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php

get_header();
?>

<div class= "wrapper">
    <main>

    <div id="titleCont">
        <h1>CHARACTERS</h1>

        <img id="filter" alt="filter icon" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/filter.png" width="2%" height="auto">

        <div id="searchContainer">
            <form action="">
            <button type="submit"><img alt="search icon" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/search.png" width="55%" height="auto"></button>
            <input type="text" placeholder="Search Movie..." name="search">
            </form>
        </div>
    </div>

    <img id="dustPos1" alt="dust totorto" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="10%" height="auto">
    <img id="dustPos2" alt="dust totorto" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="20%" height="auto">
    <img id="dustPos3" alt="dust totorto" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="10%" height="auto">

<?php
 // The Query
 $the_query = new WP_Query( array(
'post_type' => 'ghibli-characters',
'post_per_page' => 9, //ALL
'orderby' => 'title',
 ) );
  
 // The Loop
 if ( $the_query->have_posts() ):
 ?>
    <div id="charContainer">
    <?php
     while ( $the_query->have_posts() ) :
     $the_query->the_post();
    ?>
    <a href="<?php the_permalink();?>">
    <div>

        <img src="<?php echo get_field('char_photo')['url']; ?>">

        <?php $movie = get_field('movie'); ?> 
        <?php $age = get_field('age'); ?>  

        <span><?php the_title();?></span>
        <span><?php echo $age?></span>
        <span><?php echo $movie?></span>
        

    </div>
     </a>
    <?php endwhile;?>

    </div>

<?php
 endif;
 /* Restore original Post Data */
 wp_reset_postdata();
 ?>

    <div id="nPag"></div>

    </main>

    <footer id="charF">
        
      <img id="broom" alt="broom" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (1).png" width="30%" height="auto">

<?php
get_footer();
