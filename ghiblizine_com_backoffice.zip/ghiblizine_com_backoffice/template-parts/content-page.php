<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ghiblizine
 */

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible'>
    <title>Article</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>

    <script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>

</head>

<body id="article">

<?php
get_header();
?>

<div class="wrapper">
        <main>
            <div>
                <h1><?php the_title() ?></h1>
                <p>
				<?php the_title() ?>
                </p>
            </div>

            <div class="imagensfundo">
                <img class="ig ig1" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (4).png">
            </div>

        </main>

		
        <footer>
<?php
get_footer();
?>
