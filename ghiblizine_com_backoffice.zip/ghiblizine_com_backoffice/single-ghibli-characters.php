<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Ghiblizine
 */
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible'>
    <title>Ghiblizine</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>

    <script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>

</head>

<body id="article">

<?php
get_header();
?>

<div class="wrapper">
        <main>
            <?php 
            $artigoID=get_field('ghibli-characters')->ID;
            
            ?>
            <div>
                <h1><?php echo get_field("name"); ?></h1>
                <img style="width:60%" src="<?php echo get_field('char_photo',$artigoID)['url']; ?>">
                <p>
                <?php echo get_field("name"); ?> has 
				<?php echo get_field("age"); ?>  years old and is a character in the movie:
                </p>
                <p>
                "<?php echo get_field("movie"); ?>".
                </p>
               
            </div>

            <div class="imagensfundo">
                <img class="ig ig1" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (4).png">
            </div>

        </main>

		
        <footer>
<?php
get_footer();
?>

