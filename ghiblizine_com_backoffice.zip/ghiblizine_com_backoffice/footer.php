<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ghiblizine
 */

?>

        <a href="ghiblicollection.com">
            <img alt="instagram" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/world-wide-web.png" width="10%" height="auto">
            ghiblicollection.com

        </a>

        <a href="instagram.com/ghibliuk">
            <img alt="instagram" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/instagram.png" width="10%" height="auto">
            instagram.com/ghibliuk
        </a>
    </footer>
</div>

<?php wp_footer(); ?>

</body>
</html>
