<?php
/**
 * Template Name: Homepage
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ghiblizine
 */?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>
	<script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>
  <script type="text/javascript">
  var url = "<?php echo get_template_directory_uri(); ?>/assets/";
  </script>

<?php wp_head(); ?>
</head>

<body id="home" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
get_header();
?>

<div class="wrapper">
    <main>
      <div id="container">

      </div>

      <div class="HorBar">
        <span class="HBcontent"> BREAKING NEWS: Hayao Miyazaki Prepares to Cast One Last Spell, new moving is on the
          works</span>
      </div>

      <h1>NEWS</h1>

      <div class="slider">

        <div class="thumbnailSlide fade">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/thumb.png" width="100%" height="auto">
          <div class="cap">Title 1</div>
        </div>

        <div class="thumbnailSlide fade">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/thumb.png" width="100%" height="auto">
          <div class="cap">Title 2</div>
        </div>

        <div class="thumbnailSlide fade">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/thumb.png" width="100%" height="auto">
          <div class="cap">Title 3</div>
        </div>

        <img class="prev" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/ArrowL.png" onclick="nxt(-1)">
        <img class="next" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/ArrowR.png" onclick="nxt(1)">

        <div style="text-align:center; position: relative; bottom:15%;">
          <img class="waiting" onclick="current(1)" width="5%" height="auto">
          <img class="waiting" onclick="current(2)" width="5%" height="auto">
          <img class="waiting" onclick="current(3)" width="5%" height="auto">
        </div>
      </div>

      <?php
 
 // The Query
 $the_query = new WP_Query(array(
  'post_type' => 'newsarticle',
  'orderby' => 'title',
  'order'   => 'DESC',
  'posts_per_page' => 8,
   ));
  
 // The Loop
 if ( $the_query->have_posts() ) :        
?>
      <div id="newsContainer">
      <?php
     while ( $the_query->have_posts() ) :
     $the_query->the_post();
    ?>

<div>
  <a href="<?php the_permalink();?>">
  <img src="<?php echo get_field('article_image')['url']; ?>" height="auto">
  <span> <?php the_title(); ?></span>
  </a>
</div>


<?php
     endwhile;
     wp_reset_postdata();
     wp_reset_query();
 ?>


        <h1> SEE MORE NEWS <span>+ </span> </h1>
        <img alt="Calcifer" id="cal" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Cal.png" width="60%" height="auto">
      </div>
      <?php
    endif;

wp_reset_postdata();?>
      <img id="dust" alt="totoro dust" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png" width="20%" height="auto">

    </main>

	<script type='text/javascript' src="<?php echo get_template_directory_uri(); ?>/assets/js/homepage.js"></script>
  	<script src="<?php echo get_template_directory_uri(); ?>/assets/js/carousel.js"></script>


    <footer>
      <img class="imgfooter" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png">

<?php
get_footer();
