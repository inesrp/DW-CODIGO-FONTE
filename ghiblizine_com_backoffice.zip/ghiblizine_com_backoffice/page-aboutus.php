<?php
/**
 * Template Name: AboutUs
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ghiblizine
 */?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel='stylesheet' type='text/css' media='screen' href='<?php echo get_template_directory_uri(); ?>/assets/sass/main.css'>
	<script src="https://cdn.jsdelivr.net/gh/dixonandmoe/rellax@master/rellax.min.js"></script>

<?php wp_head(); ?>
</head>

<body id="aboutus" <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php

get_header();
?>



<div class="wrapper">
        <main>
            <div>
                <h1>ABOUT GHIBLI</h1>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et
                    dolore magna aliqua. Duis at tellus at urna condimentum mattis pellentesque id. Diam sit amet nisl
                    suscipit. Mauris a diam maecenas sed. Habitant morbi tristique senectus et netus et. Nunc vel risus
                    commodo viverra maecenas accumsan lacus. Congue quisque egestas diam in. Viverra ipsum nunc aliquet
                    bibendum enim. Ipsum consequat nisl vel pretium lectus quam id leo. Cursus metus aliquam eleifend mi
                    in
                    nulla. Arcu non odio euismod lacinia at quis risus sed vulputate. Ullamcorper eget nulla facilisi
                    etiam
                    dignissim. Pharetra convallis posuere morbi leo urna molestie. Id diam maecenas ultricies mi eget
                    mauris. Tristique senectus et netus et malesuada.
                </p>
            </div>

            <div class="imagensfundo">
                <img class="ig ig1" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png">
                <img class="ig ig2" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (4).png">
                <img class="ig ig3" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (6).png">
                <img class="ig ig4" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/dust.png">
            </div>


            <div>
                <h1>ABOUT US</h1>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et
                    dolore magna aliqua. Duis at tellus at urna condimentum mattis pellentesque id. Diam sit amet nisl
                    suscipit. Mauris a diam maecenas sed. Habitant morbi tristique senectus et netus et. Nunc vel risus
                    commodo viverra maecenas accumsan lacus. Congue quisque egestas diam in. Viverra ipsum nunc aliquet
                    bibendum enim. Ipsum consequat nisl vel pretium lectus quam id leo. Cursus metus aliquam eleifend mi
                    in
                    nulla. Arcu non odio euismod lacinia at quis risus sed vulputate. Ullamcorper eget nulla facilisi
                    etiam
                    dignissim. Pharetra convallis posuere morbi leo urna molestie. Id diam maecenas ultricies mi eget
                    mauris. Tristique senectus et netus et malesuada.
                </p>
            </div>
        </main>


        <footer>
            <img class="imgfooter" src="<?php echo get_template_directory_uri(); ?>/assets/assets/imgs/Hero (10).png">



<?php
get_footer();
