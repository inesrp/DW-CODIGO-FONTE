/*var newC = document.getElementById('moviesContainer');

for(let i=1; i<=9; i++){
        var div = document.createElement('div');
        var img = document.createElement('img');
        var movieTitle = document.createElement('span');
        var year = document.createElement('span');
        var length = document.createElement('span');
        img.setAttribute('src', '../assets/imgs/mc.png');
        img.setAttribute('height', 'auto');
        movieTitle.innerText  ='Movie Title ' + i;
        year.innerText ='Ano ' + i;
        length.innerText  ='1:00:0' + i;
        div.appendChild(img);
        div.appendChild(movieTitle);
        div.appendChild(year);
        div.appendChild(length);
        newC.appendChild(div);
}

var nPag = document.getElementById('nPag');
for(let i=1; i<=5; i++){
    var div = document.createElement('div');
    var num = document.createElement('span');
    num.innerText = i;
    div.appendChild(num);
    nPag.appendChild(div);
} */